const num1 = document.getElementById('num1') as HTMLInputElement;
const num2 = document.getElementById('num2') as HTMLInputElement;
const operacao = document.getElementById('operacao') as HTMLSelectElement;
const btnCalcular = document.getElementById('calcular') as HTMLButtonElement;
const resultado = document.getElementById('resultado') as HTMLParagraphElement;

btnCalcular.addEventListener('click', () => {
  const valor1 = parseFloat(num1.value);
  const valor2 = parseFloat(num2.value);

  if (isNaN(valor1) || isNaN(valor2)) {
    resultado.textContent = "Por favor, insira números válidos.";
    return;
  }

  let res: number;

  switch (operacao.value) {
    case 'somar':
      res = valor1 + valor2;
      break;
   case 'subtrair':
  res = valor1 - valor2;
  break;
    case 'multiplicar':
      res = valor1 * valor2;
      break;
    case 'dividir':
      if (valor2 === 0) {
        resultado.textContent = "Não é possível dividir por zero!";
        return;
      }
      res = valor1 / valor2;
      break;
    default:
      resultado.textContent = "Operação inválida.";
      return;
  }

  resultado.textContent = `Resultado: ${res}`;
});
