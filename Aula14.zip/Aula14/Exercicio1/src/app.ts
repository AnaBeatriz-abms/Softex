
const botao = document.getElementById('botaoApresentar') as HTMLButtonElement;
const campoTexto = document.getElementById('meuCampoTexto') as HTMLInputElement;
const resultado = document.getElementById('resultado') as HTMLParagraphElement;

// Adicionando o event listener com tipagem correta
botao.addEventListener('click', (): void => {
  const textoDigitado: string = campoTexto.value;
  resultado.textContent = `Você escreveu: ${textoDigitado}`;
});
